package com.renan.curso.boot.service;

public interface FuncionarioService {

}
